package model;

public abstract class FormaDePagamento {
	
	public abstract String imprimePagamento(Double pagamento);

}
