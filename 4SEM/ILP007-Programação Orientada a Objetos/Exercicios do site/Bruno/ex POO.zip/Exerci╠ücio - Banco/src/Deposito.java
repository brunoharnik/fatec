
public class Deposito extends Transacao {

}
