
public class Saque extends Transacao {

}
