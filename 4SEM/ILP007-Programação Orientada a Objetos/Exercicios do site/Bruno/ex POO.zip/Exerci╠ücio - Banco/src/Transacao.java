import java.util.Date;

public class Transacao {
	
	private double valor;
	private Date data;
}
