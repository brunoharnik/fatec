
public class CaixaEletronico {
	
	public Conta autentica(String numeroConta, String senha) {
		return null;
	}
}
