
public class Pagamento extends Transacao {
	
	private String boleto;
}
