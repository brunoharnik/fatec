
public interface Interceptador {

}
