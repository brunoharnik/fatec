package edu.nobreza;

public class Diplomata {

	public void fazerDiplomacia() {
		System.out.println("Fazendo Diplomacia");
	}
}
