package edu.nobreza;

public class Rainha{
	
	public Rainha(){
		Diplomata diplomata = new Diplomata();		
		diplomata.fazerDiplomacia();
	}
}
