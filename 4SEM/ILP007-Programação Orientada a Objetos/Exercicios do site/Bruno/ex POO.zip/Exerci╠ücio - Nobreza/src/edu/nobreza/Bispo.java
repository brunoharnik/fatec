package edu.nobreza;

public class Bispo extends Padre {

}
