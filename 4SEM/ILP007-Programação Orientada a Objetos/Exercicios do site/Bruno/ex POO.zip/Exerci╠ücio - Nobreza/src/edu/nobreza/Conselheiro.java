package edu.nobreza;

import java.util.HashSet;
import java.util.Set;

public class Conselheiro {

	Set<Bispo> bispaiada = new HashSet<Bispo>();
}
