package edu.nobreza;

public class Padre implements Fiel{

	@Override
	public void rezar() {
		System.out.println("Orando...");
	}

}
