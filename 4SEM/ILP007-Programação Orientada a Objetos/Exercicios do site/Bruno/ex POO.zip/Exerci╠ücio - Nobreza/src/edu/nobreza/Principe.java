package edu.nobreza;

public class Principe extends Nobre {

	public Principe() {
		Cavaleiro cavaleiro = new Cavaleiro();
		cavaleiro.duelar();
	}
}
