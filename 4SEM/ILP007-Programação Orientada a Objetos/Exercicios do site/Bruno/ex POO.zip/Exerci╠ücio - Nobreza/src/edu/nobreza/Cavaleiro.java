package edu.nobreza;

public class Cavaleiro {

	public void duelar() {
		System.out.println("Duelando");
	};
}
