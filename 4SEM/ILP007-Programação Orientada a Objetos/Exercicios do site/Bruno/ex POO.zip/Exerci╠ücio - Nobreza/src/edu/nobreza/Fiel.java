package edu.nobreza;

public interface Fiel {
	void rezar();
}
