
public interface Observador {
	void recebeNoticia(String noticia);
}